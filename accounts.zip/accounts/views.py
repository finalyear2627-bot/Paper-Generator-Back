from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import User
from .serializers import UserSerializer
from .permissions import IsAdmin

@api_view(['GET'])
def current_user(request):
    serializer = UserSerializer(request.user)
    return Response(serializer.data)

@api_view(['GET'])
def list_users(request):
    if not request.user.role == 'ADMIN':
        return Response({'detail': 'Forbidden'}, status=403)
    users = User.objects.all()
    serializer = UserSerializer(users, many=True)
    return Response(serializer.data)
