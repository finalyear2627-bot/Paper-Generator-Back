from django.urls import path
from .views import current_user, list_users

urlpatterns = [
    path('me/', current_user),
    path('users/', list_users),
]
